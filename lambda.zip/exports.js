var https = require('https');

var venthoodApplianceIdLight = "374f8c28-4885-11e6-beb8-9e71128cae77";
var venthoodApplianceIdFan = "9cb60496-7814-4f7f-8698-ccc9ae752cfe";
var venthoodLobbyLight = "1a74da45-fe80-4725-b808-d8026db19c2b";
var venthoodLobbyFan = "c8817fc7-35e8-4fea-a110-5f4c0ccc7f4e";

var particleServer = "api.particle.io";
var particlePath = "/v1/devices/";

/**
 * Main entry point.
 * Incoming events from Alexa Lighting APIs are processed via this method.
 */
exports.handler = function(event, context) {

    log('Input', event);

    switch (event.header.namespace) {
        
        /**
         * The namespace of "Discovery" indicates a request is being made to the lambda for
         * discovering all appliances associated with the customer's appliance cloud account.
         * can use the accessToken that is made available as part of the payload to determine
         * the customer.
         */
        case 'Alexa.ConnectedHome.Discovery':
            handleDiscovery(event, context);
            break;

            /**
             * The namespace of "Control" indicates a request is being made to us to turn a
             * given device on, off or brighten. This message comes with the "appliance"
             * parameter which indicates the appliance that needs to be acted on.
             */
        case 'Alexa.ConnectedHome.Control':
            handleControl(event, context);
            break;

            /**
             * We received an unexpected message
             */
        default:
            log('Err', 'No supported namespace: ' + event.header.namespace);
            context.fail('Something went wrong');
            break;
    }
};

/**
 * This method is invoked when we receive a "Discovery" message from Alexa Connected Home Skill.
 * We are expected to respond back with a list of appliances that we have discovered for a given
 * customer. 
 */
function handleDiscovery(accessToken, context) {

    /**
     * Crafting the response header
     */
    var headers = {
        namespace: 'Alexa.ConnectedHome.Discovery',
        name: 'DiscoverAppliancesResponse',
        payloadVersion: '2'
    };

    /**
     * Response body will be an array of discovered devices.
     */
    var appliances = [];

    var venthoodLight = {
        applianceId: venthoodApplianceIdLight,
        manufacturerName: 'GE',
        modelName: 'Monogram',
        version: '0.0.1',
        friendlyName: 'Lamp',
        friendlyDescription: 'Venthood lights in kitchen',
        isReachable: true,
        actions:[
            "turnOn",
            "turnOff"
        ],
        additionalApplianceDetails: {
            /**
             * OPTIONAL:
             * We can use this to persist any appliance specific metadata.
             * This information will be returned back to the driver when user requests
             * action on this appliance.
             */
            fullApplianceId: 'N/A',
            deviceId: "2e0048000447343233323032"
        }
    };

    var venthoodFan = {
        applianceId: venthoodApplianceIdFan,
        manufacturerName: 'GE',
        modelName: 'Monogram',
        version: '0.0.1',
        friendlyName: 'Turbine',
        friendlyDescription: 'Venthood fan in kitchen',
        isReachable: true,
        actions:[
            "setPercentage",
            "turnOn",
            "turnOff"
        ],
        additionalApplianceDetails: {
            /**
             * OPTIONAL:
             * We can use this to persist any appliance specific metadata.
             * This information will be returned back to the driver when user requests
             * action on this appliance.
             */
            fullApplianceId: 'N/A',
            deviceId: "2e0048000447343233323032"
        }
    };
    
    var venthoodLobbyDemoLight = {
        applianceId: venthoodLobbyLight,
        manufacturerName: 'GE',
        modelName: 'Monogram',
        version: '0.0.2',
        friendlyName: 'Lights',
        friendlyDescription: 'Venthood lights in Lobby',
        isReachable: true,
        actions:[
            "incrementPercentage",
            "decrementPercentage",
            "setPercentage",
            "turnOn",
            "turnOff"
        ],
        additionalApplianceDetails: {
            /**
             * OPTIONAL:
             * We can use this to persist any appliance specific metadata.
             * This information will be returned back to the driver when user requests
             * action on this appliance.
             */
            fullApplianceId: 'N/A',
            deviceId: "370028001747343337363432"
        }
    };
    
    var venthoodLobbyDemoFan = {
        applianceId: venthoodLobbyFan,
        manufacturerName: 'GE',
        modelName: 'Monogram',
        version: '0.0.2',
        friendlyName: 'Exhaust',
        friendlyDescription: 'Venthood fan in Lobby',
        isReachable: true,
        actions:[
            "setPercentage",
            "turnOn",
            "turnOff"
        ],
        additionalApplianceDetails: {
            /**
             * OPTIONAL:
             * We can use this to persist any appliance specific metadata.
             * This information will be returned back to the driver when user requests
             * action on this appliance.
             */
            fullApplianceId: 'N/A',
            deviceId: "370028001747343337363432"
        }
    };
    
	appliances.push(venthoodFan);
    appliances.push(venthoodLight);
    appliances.push(venthoodLobbyDemoFan);
    appliances.push(venthoodLobbyDemoLight);

    /**
     * Craft the final response back to Alexa Connected Home Skill. This will include all the 
     * discoverd appliances.
     */
    var payloads = {
        discoveredAppliances: appliances
    };
    var result = {
        header: headers,
        payload: payloads
    };

    log('Discovery', result);

    context.succeed(result);
}

/**
 * Control events are processed here.
 * This is called when Alexa requests an action (IE turn off appliance).
 */
function handleControl(event, context) {
    if (event.header.namespace === 'Alexa.ConnectedHome.Control') {

        /**
         * Retrieve the appliance id and accessToken from the incoming message.
         */
        var accessToken = event.payload.accessToken;
        var applianceId = event.payload.appliance.applianceId;
        var deviceid = event.payload.appliance.additionalApplianceDetails.deviceId;
        var message_id = event.header.messageId;
        var param = "";
        var state = 0;
        var index = "0";
        var confirmation;
        var funcName;
        var incDecIdentifier = "";
        
        log("Access Token: ", accessToken);
        log("DeviceID: ", deviceid);

        if(event.header.name == "TurnOnRequest"){
            state = 1;
            confirmation = "TurnOnConfirmation";
            funcName = "onoff";
        }
        else if(event.header.name == "TurnOffRequest"){
            state = 0;            
            confirmation = "TurnOffConfirmation";
            funcName = "onoff";
        }
        else if(event.header.name == "SetPercentageRequest"){
            state = event.payload.percentageState.value;
            confirmation = "SetPercentageConfirmation";
            funcName = "setvalue";
        }
        else if(event.header.name == "IncrementPercentageRequest"){
            var increment = event.payload.deltaPercentage.value;
            
            state += increment;
            
            if(state > 100){
                state = 100;
            }
            
            incDecIdentifier = 1;
            
            confirmation = "IncrementPercentageConfirmation";
            funcName = "setvalue";
        }
        else if(event.header.name == "DecrementPercentageRequest"){
            var decrement = event.payload.deltaPercentage.value;
            
            state = decrement;
            
            if(state < 0){
                state = 0;
            }
            
            incDecIdentifier = 0;
            
            confirmation = "DecrementPercentageConfirmation";
            funcName = "setvalue";
        }
        
        log('applianceId', applianceId);
        
		if(applianceId == venthoodApplianceIdLight || applianceId == venthoodLobbyLight) {
			index = "0";
		} else if(applianceId == venthoodApplianceIdFan || applianceId == venthoodLobbyFan) {
			index = "1";
		}

        if (incDecIdentifier == "") {
            param = index + "=" + state;
        } else {
            param = index + "=" + state + "=" + incDecIdentifier;
        }
        
        var options = {
            hostname: particleServer,
            port: 443,
            path: particlePath + deviceid + "/" + funcName,
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded'
            }
        };
        
        log(options);
        
        var data = "access_token=" + accessToken + "&" + "args=" + param;
        
        log(data);

        var serverError = function (e) {
            log('Error', e.message);
            context.fail(generateControlError('TurnOnRequest', 'DEPENDENT_SERVICE_UNAVAILABLE', 'Unable to connect to server'));
        };

        var callback = function(response) {
            var str = '';

            response.on('data', function(chunk) {
                str += chunk.toString('utf-8');
            });

            response.on('end', function() {
                log('Return Value');
                log(str);
                
                var headers = {
                    namespace: 'Alexa.ConnectedHome.Control',
                    name: confirmation,
                    payloadVersion: '2',
                    messageId: message_id
                };
                var payloads = {
                    
                };
                var result = {
                    header: headers,
                    payload: payloads
                };

                context.succeed(result);
            });

            response.on('error', serverError);
        };

        var req = https.request(options, callback);
            
        req.on('error', serverError);
        
        req.write(data);
        req.end();
    }
}

/**
 * Utility functions.
 */
function log(title, msg) {
    console.log(title + ": " + msg);
}

function generateControlError(name, code, description) {
    var headers = {
        namespace: 'Control',
        name: name,
        payloadVersion: '1'
    };

    var payload = {
        exception: {
            code: code,
            description: description
        }
    };

    var result = {
        header: headers,
        payload: payload
    };

    return result;
}